﻿using Microsoft.EntityFrameworkCore;
using Model.HelloWorld;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataAccess.HelloWorld.Context
{
   public class HelloCoreDBContext : DbContext
    {
        public HelloCoreDBContext(DbContextOptions<HelloCoreDBContext> options) : base(options)
        {
            //
        }
        public DbSet<Demos> Demo { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
        }

        public override int SaveChanges()
        {
            return base.SaveChanges();
        }
    }
}
