﻿using System;

namespace Model.HelloWorld
{
    public class Demos
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
