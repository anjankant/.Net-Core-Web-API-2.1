﻿using HelloCore2.Data.Model;
using System.Collections.Generic;

namespace HelloCore2.Data.Infrastructure
{
    public interface IDemoHelo
    {
        //List<Demos> GetDemo();
        List<Demos> GetDemo();
    }
}
