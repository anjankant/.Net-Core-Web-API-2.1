﻿using HelloCore2.Data.Infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HelloCore2.Data.Model;
using HelloCore2.Data.Context;

namespace HelloCore2.Data.DataService
{
    public class DemoHello: IDemoHelo
    {
        private readonly HelloCoreDBContext _context;
        public DemoHello(HelloCoreDBContext context) 
        {
            _context = context;
        }
        public List<Demos> GetDemo()
        {
            //var context = new HelloCoreDBContext();
            return _context.Demo.ToList();
            //List<string> lst = new List<string>();
            //lst.Add("test");
            //lst.Add("test1");
            //return lst;
            
            //return context.Demo.ToList();
            //return List<Demos>
        }
    }
}
