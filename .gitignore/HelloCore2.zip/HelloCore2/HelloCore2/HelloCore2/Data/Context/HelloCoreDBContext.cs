﻿using HelloCore2.Data.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HelloCore2.Data.Context
{
    public class HelloCoreDBContext : DbContext
    {
        public HelloCoreDBContext(DbContextOptions<HelloCoreDBContext> options) : base(options)
        {
            //
        }

        public DbSet<Demos> Demo { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
        }

        public override int SaveChanges()
        {
            return base.SaveChanges();
        }
    }
}
