﻿using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using Model.HelloWorld;
using Service.HelloCore.Data.DataService;
using Service.HelloCore.Data.Infrastructure;

namespace HelloCore2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ValuesController : ControllerBase
    {
        private readonly IDemoHelo _context;
        public ValuesController(IDemoHelo context)
        {
            _context = context;
        }
        // GET api/values
        [HttpGet]
        public ActionResult<IEnumerable<Demos>> Get()
        {
            return _context.GetDemo();

           // return new string[] { "value1", "value2" };
        }

        // GET api/values/5
        [HttpGet("{id}")]
        public ActionResult<string> Get(int id)
        {
            return "value";
        }

        // POST api/values
        [HttpPost]
        public void Post([FromBody] string value)
        {
        }

        // PUT api/values/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
