﻿using Service.HelloCore.Data.Infrastructure;
using System;
using System.Collections.Generic;
using System.Text;
using DataAccess.HelloWorld.Context;
using Model.HelloWorld;
using System.Linq;

namespace Service.HelloCore.Data.DataService
{
    public class DemoHello: IDemoHelo
    {
        private readonly HelloCoreDBContext _context;
        public DemoHello(HelloCoreDBContext context)
        {
            _context = context;
        }
        public List<Demos> GetDemo()
        {
            //var context = new HelloCoreDBContext();
            return _context.Demo.ToList();
        }
    }
}
