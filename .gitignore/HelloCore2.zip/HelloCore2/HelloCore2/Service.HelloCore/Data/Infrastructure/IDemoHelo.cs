﻿using Model.HelloWorld;
using System;
using System.Collections.Generic;
using System.Text;

namespace Service.HelloCore.Data.Infrastructure
{
    public interface IDemoHelo
    {
        List<Demos> GetDemo();
    }
}
